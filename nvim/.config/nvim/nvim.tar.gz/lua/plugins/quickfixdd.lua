-- Adds delete functionality to quickfix list (keymap dd)
return {
  -- https://github.com/TamaMcGlinn/quickfixdd
  'TamaMcGlinn/quickfixdd',
  event = 'VeryLazy'
}
