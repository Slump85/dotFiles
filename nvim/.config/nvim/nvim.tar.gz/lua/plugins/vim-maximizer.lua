-- Maximize and Restore Current Window
return {
  -- https://github.com/szw/vim-maximizer
  'szw/vim-maximizer',
  event = 'VeryLazy',
}

