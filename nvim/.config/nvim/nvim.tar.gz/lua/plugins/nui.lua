return { "MunifTanjim/nui.nvim", lazy = true }
